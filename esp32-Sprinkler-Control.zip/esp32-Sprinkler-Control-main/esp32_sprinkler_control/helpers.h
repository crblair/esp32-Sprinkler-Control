#ifndef HELPERS_H
#define HELPERS_H

#include <Arduino.h>

// Placeholder for helper functions
// You can add utility functions here if needed

#endif // HELPERS_H