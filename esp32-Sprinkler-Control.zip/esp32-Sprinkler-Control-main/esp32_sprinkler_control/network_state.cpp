#include "network_state.h"

const char* NetworkState::DEFAULT_SSID = "Toucan Dream 1";
const char* NetworkState::DEFAULT_PASSWORD = "Poolisnext22";
